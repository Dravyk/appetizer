-- hide appetizer after startup
function appetizer_hide()
	if appetizer:isVisible() then
		appetizer:hide()
	end
end

-- call the function
appetizer_hide()
